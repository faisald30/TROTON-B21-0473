package com.bangkit.maskcam.datacorona.entity

data class CoronaWorld(
    val attributes: Corona
)
