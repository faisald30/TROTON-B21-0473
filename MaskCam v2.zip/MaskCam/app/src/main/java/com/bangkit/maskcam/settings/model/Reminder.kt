package com.bangkit.maskcam.settings.model

data class Reminder(
    var isReminded: Boolean = false
)
