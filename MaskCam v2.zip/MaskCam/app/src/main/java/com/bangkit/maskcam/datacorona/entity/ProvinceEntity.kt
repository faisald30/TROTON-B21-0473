package com.bangkit.maskcam.datacorona.entity

data class ProvinceEntity (
    val attributes: ProvenceEntity
    )