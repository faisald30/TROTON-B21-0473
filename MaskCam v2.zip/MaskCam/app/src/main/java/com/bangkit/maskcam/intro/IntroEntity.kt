package com.bangkit.maskcam.intro

data class IntroEntity (
    val image: Int,
    val title: String,
    val desc: String
)