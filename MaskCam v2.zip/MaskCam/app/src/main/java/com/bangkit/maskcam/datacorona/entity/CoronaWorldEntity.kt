package com.bangkit.maskcam.datacorona.entity

data class CoronaWorldEntity(
    val value: String
)
