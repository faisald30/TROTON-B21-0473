package com.bangkit.maskcam.datacorona.entity


data class IndonesiaEntity(
    val positif: String,
    val sembuh: String,
    val meninggal: String
)
