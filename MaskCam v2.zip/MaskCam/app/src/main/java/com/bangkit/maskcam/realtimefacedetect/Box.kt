package com.bangkit.maskcam.realtimefacedetect

import android.graphics.RectF

class Box(val rectF: RectF, val label: String, val isMask: Boolean)